# plugin.audio.goonbag

## About

An audio plugin for XBMC that allows you to play the live streams from [Goonbag Radio](http://www.goonbag.com/)

Currently does not support podcasts or video from the YouTube channel, but will.

## Why?

Goonbag is the future.

## Thanks, Kudos & Legalities

* Team XBMC
* All the crew at Goonbag Radio
* t0mm0 ([plugin.audio.jazzfm](https://github.com/t0mm0/t0mm0-xbmc-plugins/tree/master/plugin.audio.jazzfm))

## Copyright

Copyright (c) 2012 [Gregory Tangey](http://ignite.digitalignition.net/). See LICENSE for details.



